package org.d3if.rememberactivities;

import android.app.AlarmManager;
import android.app.DatePickerDialog;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.support.v4.app.NotificationCompat;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TimePicker;

import java.util.ArrayList;
import java.util.Calendar;

public class detailingActivity extends AppCompatActivity {
    EditText namakegiatan,date,time,datedone,timedone,catatan;
    Spinner pengingatsebelum,pengulangan;
    DatePickerDialog datePickerDialog,datePickerDialogdone;
    public ArrayList<simpankegiatan> arr;
    final String message = "ini adalah contoh notifikasi";
    final String title = "ini adalah judul";
    final static int RQS_1 = 1;
    String namaAktivitas,pengingat,pengulanganwaktu;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detailing);
          namakegiatan = (EditText) findViewById(R.id.activitiename);
         pengingatsebelum = (Spinner) findViewById(R.id.remindme);
         pengulangan = (Spinner) findViewById(R.id.repeat);
        catatan = (EditText) findViewById(R.id.note);
        namaAktivitas = namakegiatan.getText().toString();
        pengingat = pengingatsebelum.getSelectedItem().toString();
        pengulanganwaktu = pengulangan.getSelectedItem().toString();
        setupActionBar();
        datebeginshow();
        timebeginshow();
        datedoneshow();
        timedoneshow();
        Button btn = (Button) findViewById(R.id.tambahdata);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                arr = new ArrayList<>();
                arr.add(new simpankegiatan(namaAktivitas, date.getText().toString(), time.getText().toString(), datedone.getText().toString(), timedone.getText().toString(), pengingat, pengulanganwaktu, catatan.getText().toString()));
                Intent intent=new Intent(detailingActivity.this, seeActivity.class);
                startActivity(intent);
                notifTemplate(message,title);
            }
        });
        Button batal=(Button)findViewById(R.id.batal);
        batal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
            namakegiatan.setText("");
            date.setText("");
            time.setText("");
            datedone.setText("");
            timedone.setText("");
            catatan.setText("");
            }
        });
    }
    private void notifTemplate(String tittle, String message) {
        final Intent intent = new Intent(detailingActivity.this,detailNotifikasiActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(detailingActivity.this,0,intent,PendingIntent.FLAG_UPDATE_CURRENT);
        NotificationCompat.Builder mBuilder = (NotificationCompat.Builder)new NotificationCompat.Builder(detailingActivity.this).
                setSmallIcon(R.mipmap.ic_launcher).setContentTitle(tittle).setContentText(message).setContentIntent(pendingIntent)
                .setAutoCancel(true).setDefaults(Notification.DEFAULT_LIGHTS | Notification.DEFAULT_SOUND | Notification.FLAG_AUTO_CANCEL);
        NotificationManager notificationManager =
                (NotificationManager)detailingActivity.this.getSystemService(Context.NOTIFICATION_SERVICE);
        notificationManager.notify(1,mBuilder.build());
    }
    private void setupActionBar() {
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            // Show the Up button in the action bar.
            actionBar.setDisplayHomeAsUpEnabled(true);
        }
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == android.R.id.home) {
            Intent in=new Intent(detailingActivity.this,firstActivity.class);
            startActivity(in);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
    private void datebeginshow(){
        date =(EditText)findViewById(R.id.date);
        date.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final Calendar c= Calendar.getInstance();
                int mYear=c.get(Calendar.YEAR);
                int mMont=c.get(Calendar.MONTH);
                int mDay=c.get(Calendar.DAY_OF_MONTH);
                datePickerDialog=new DatePickerDialog(detailingActivity.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                        date.setText(day+"/"+month+"/"+year);
                    }
                },mYear,mMont,mDay);
                datePickerDialog.show();
            }
        });
    }
    private void datedoneshow(){
        datedone =(EditText)findViewById(R.id.datedone);
        datedone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final Calendar c= Calendar.getInstance();
                int mYear=c.get(Calendar.YEAR);
                int mMont=c.get(Calendar.MONTH);
                int mDay=c.get(Calendar.DAY_OF_MONTH);
                datePickerDialogdone=new DatePickerDialog(detailingActivity.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                        datedone.setText(day+"/"+month+"/"+year);
                    }
                },mYear,mMont,mDay);
                datePickerDialogdone.show();
            }
        });
    }
    private void timebeginshow(){
        time=(EditText)findViewById(R.id.timee);
        time.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Calendar mCurentTime=Calendar.getInstance();
                int hour=mCurentTime.get(Calendar.HOUR_OF_DAY);
                int minute=mCurentTime.get(Calendar.MINUTE);
                TimePickerDialog mtimepicker;
                mtimepicker=new TimePickerDialog(detailingActivity.this,onTimeSetListener ,
                hour,minute,true);
                mtimepicker.setTitle("Select Time");
                mtimepicker.show();
            }
        });

        }
    TimePickerDialog.OnTimeSetListener onTimeSetListener=new TimePickerDialog.OnTimeSetListener() {
        @Override
        public void onTimeSet(TimePicker timePicker, int i, int i1) {
            Calendar calNow = Calendar.getInstance();
            Calendar calSet = (Calendar) calNow.clone();

            calSet.set(Calendar.HOUR_OF_DAY, i);
            calSet.set(Calendar.MINUTE, i1);
            calSet.set(Calendar.SECOND, 0);
            calSet.set(Calendar.MILLISECOND, 0);

            if (calSet.compareTo(calNow) <= 0) {
                // Today Set time passed, count to tomorrow
                calSet.add(Calendar.DATE, 1);
                Log.i("hasil", " =<0");
            } else if (calSet.compareTo(calNow) > 0) {
                Log.i("hasil", " > 0");
            } else {
                Log.i("hasil", " else ");
            }

            setAlarm(calSet);
        }
    };
    private void setAlarm(Calendar target){

        Intent intent=new Intent(getBaseContext(),Alarmrecivier.class);
        PendingIntent pendingIntent=PendingIntent.getBroadcast(getBaseContext(),RQS_1,intent,0);
        AlarmManager alarmManager=(AlarmManager)getSystemService(Context.ALARM_SERVICE);
        alarmManager.set(AlarmManager.RTC_WAKEUP,target.getTimeInMillis(),pendingIntent);
    }
    private void timedoneshow(){
        timedone=(EditText)findViewById(R.id.timedone);
        timedone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Calendar mCurentTime=Calendar.getInstance();
                int hour=mCurentTime.get(Calendar.HOUR_OF_DAY);
                int minute=mCurentTime.get(Calendar.MINUTE);
                TimePickerDialog mtimepickerdone;
                mtimepickerdone=new TimePickerDialog(detailingActivity.this, new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker timePicker, int hour, int minute) {
                        timedone.setText(hour+":"+minute);
                    }
                },hour,minute,true);
                mtimepickerdone.setTitle("Select Time");
                mtimepickerdone.show();
            }
        });
    }
}
