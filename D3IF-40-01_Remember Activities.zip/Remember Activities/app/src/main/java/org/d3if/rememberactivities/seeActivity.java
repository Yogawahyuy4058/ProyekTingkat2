package org.d3if.rememberactivities;

import android.content.DialogInterface;
import android.content.Intent;
import android.media.Image;
import android.provider.ContactsContract;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class seeActivity extends AppCompatActivity {
    ArrayList<simpankegiatan> arr;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_see);

        final ListView lis=(ListView)findViewById(R.id.myactivites);
         arr=new ArrayList<>();
        arr.add(new simpankegiatan("Memancing","12/07/2018","15.30","12/07/2018","17.00","5 menit","2 kali","harus pulang jam 17.00"));
        arr.add(new simpankegiatan("Rapat Kerja","16/07/2018","15.30","12/07/2018","17.00","5 menit","2 kali","harus pulang jam 17.00"));
        arr.add(new simpankegiatan("Pergi Ke Rumah Nenek","20/07/2018","15.30","12/07/2018","17.00","5 menit","2 kali","harus pulang jam 17.00"));
        custom_adapter adapter=new custom_adapter(getApplicationContext(),R.layout.customlayoutlistview,arr);
        lis.setAdapter(adapter);
        lis.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                startActivity(new Intent(seeActivity.this,detailviewActivity.class));
            }
        });
        registerForContextMenu(lis);
        setupActionBar();
    }
    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        if(v.getId()==R.id.myactivites){
           AdapterView.AdapterContextMenuInfo info=(AdapterView.AdapterContextMenuInfo)menuInfo;

            String [] menuitem=getResources().getStringArray(R.array.menu);
            for (int i = 0; i <menuitem.length ; i++) {
                menu.add(Menu.NONE,i,i,menuitem[i]);
            }
        }

    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
       AdapterView.AdapterContextMenuInfo info=(AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
       int menuItemIndex=item.getItemId();
        String [] menuItem=getResources().getStringArray(R.array.menu);
        String  menuItemName=menuItem[menuItemIndex];
        simpankegiatan ListitemName=arr.get(info.position);
        for (int i = 0; i <menuItem.length ; i++) {
            if(menuItem[i].equalsIgnoreCase("Edit")){
                startActivity(new Intent(seeActivity.this,detailingActivity.class));
            }else if(menuItem[i].equalsIgnoreCase("Hapus")) {
                /*to do*/
                final AlertDialog.Builder alert= new android.support.v7.app.AlertDialog.Builder(this);
                alert.setTitle("Hapus kegiatan");
                alert.setMessage("Yakin hapus kegiatan ini?");
                alert.setCancelable(true);
                alert.setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Toast toast=Toast.makeText(getApplicationContext(),"Kegiatan terhapus",Toast.LENGTH_SHORT);
                        toast.show();
                    }
                });
                alert.setNegativeButton(android.R.string.no, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.cancel();
                    }
                });
                //AlertDialog alert1=alert.create();
                alert.show();
            }
        }
       return true;
    }
    private void setupActionBar() {
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            // Show the Up button in the action bar.
            actionBar.setDisplayHomeAsUpEnabled(true);
        }
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == android.R.id.home) {
            Intent in=new Intent(seeActivity.this,firstActivity.class);
            startActivity(in);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

}
